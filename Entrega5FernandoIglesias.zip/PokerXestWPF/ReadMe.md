#Entrega 4
#Actualizada a versi�n de .net que se usa(8.0) m�is a de Visual Studio Community 2022. 
###Funcionalidades incluidas: crear, editar e eliminar --> nesta versi�n solo se implementan para xogador, pero tam�n se implementar�n en repartidores e torneos.
###Funcionalidades futuras: Controlarase que o DNI introducido te�a un formato v�lido, que o xogador sexa maior ou igual a 18 anos, 
###que non se poida crear un torneo con fecha anterior � actual e tam�n permitir� calcular os premios unha vez pechado o rexistro tard�o.
###Nesta versi�n a interfaz non vai ir como quedar�a � final porque non me deu tempo a�nda, solo � para ver que funcionan as funci�ns. A mi�a idea
### � que se vexa unha lista tanto dos xogadores coma dos repartidores coma dos torneos e que en cada fila haxa un bot�n para editar e para borrar. O bot�n de crear si que quedar�a onde est�.
### Os formularios tam�n intentarei melloralos.
### Por favor, se ves necesaria algunha funcionalidade m�is faimo saber. A mi�a idea � que na pesta�a de finanzas poidamos ver o que se leva ingresado en comisi�ns e o que se 
### leva gastado en soldos dos repartidores
### Na pesta�a de panel de control a mi�a idea � que se vexa �nicamente o n�mero total de xogadores rexistrados, repartidores e torneos
### Na pesta�a de torneos � onde se poder�n levar a cabo os rexistros de xogadores.

